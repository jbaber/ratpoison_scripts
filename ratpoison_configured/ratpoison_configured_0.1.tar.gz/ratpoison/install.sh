#!/usr/bin/env bash
#
# Install a profile for ratpoison.
#
# If $1 not given, install the simple configuration for ratpoison
# If $1 given, install profile $1 for ratpoison

function die() {
    echo "$0 error: $*"
    exit 1
}

profile=simple
[ $# -eq 1 ] && profile=$1

[ -z "$HOME" ] && die "The \$HOME environment variable must be set"
cd $HOME || die "can't cd $HOME"
if [ -f .ratpoisonrc ]; then
    mv .ratpoisonrc .ratpoisonrc.old \
        || die "error moving old .ratpoisonrc file out of the way"
fi

[ -d .ratpoison ] || die "Untar the ratpoison_configured_X.tar.gz file in your home first"
[ -f .ratpoison/ratpoisonrc ] || die "file .ratpoison/ratpoisonrc not found"
ln -s .ratpoison/ratpoisonrc .ratpoisonrc

cd .ratpoison || die "couldn't cd .ratpoison"

rm -f workspace.conf 
[ -f workspace.conf.$profile ] || die "file workspace.conf.$profile not found"
ln -s workspace.conf.$profile workspace.conf

rm -f xinitrc
[ -f xinitrc.$profile ] || die "file xinitrc.$profile not found"
ln -s xinitrc.$profile xinitrc

cd macro || die "couldn't cd macro"

rm -f xbindkeysrc
[ -d xbindkeysrc.$profile ] || die "file xbindkeysrc.$profile not found"
ln -s xbindkeysrc.$profile xbindkeysrc
